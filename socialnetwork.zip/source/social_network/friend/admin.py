from django.contrib import admin

from friend.models import *

admin.site.register(FriendRequest)